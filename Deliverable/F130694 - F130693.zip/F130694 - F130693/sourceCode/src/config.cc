/*
 * config.cc
 *
 *  Created on: Jan 24, 2014
 *      Author: segmentedbit
 */

#include "includes/config.h"

bool config::DEBUG = false;


