/*
 * config.h
 *
 *  Created on: Jan 7, 2014
 *      Author: fenrir
 */

#ifndef CONFIG_H_
#define CONFIG_H_

namespace config {

extern bool DEBUG;

}

#endif /* CONFIG_H_ */
